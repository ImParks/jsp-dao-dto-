package com.Jsp.Board.BoardDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.Jsp.Board.Board;
import com.Jsp.Board.LoginDB.Login;

public class Dao extends Db {
	private static Connection con = null;
	private static Statement st = null;
	private static ResultSet rs = null;
	private static Dto post = null;
	private static ArrayList<Dto> posts = new ArrayList<>();
	private static int minpage;
	private static int count;

	public void post(Dto a) {
		post = null;
		post = a;
	}

	public void dao(String a, String b) {
		try {
			Class.forName(DB_LINK);
			con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
			st = con.createStatement();
			if (a.equals("del")) {
				del(b);
			} else if (a.equals("write")) {
				write();
			} else if (a.equals("read")) {
				read(b);
			} else if (a.equals("list")) {
				list(b);
			} else if (a.equals("fix")) {
				fix(b);
			} else if (a.equals("count")) {
				count(b);
			}

			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 삭제
	private static void del(String a) {
		String sql = String.format("DELETE FROM %s WHERE B_no = %s", DB_NAME, a);
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 쓰기
	private static void write() {
String no = Login.no();
		if(no == null) {
			no = "0";
		}
		
		String sql = String.format(
				"INSERT INTO %s(B_time,B_title,B_num,B_name,B_name_num,B_text) VALUES (now(),'%s',%s,'%s',%s,'%s')",DB_NAME,
				post.title,no,post.name,post.num,post.text);
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 읽기
	private static void read(String a) {
		String sql = String.format("SELECT * FROM %s WHERE B_no = %s", DB_NAME, a);

		try {
			rs = st.executeQuery(sql);

			rs.next();

			post = new Dto(rs.getString("B_no"), rs.getString("B_title"), rs.getString("B_time"),
					rs.getString("B_name"),rs.getString("B_name_num"), rs.getString("B_hit"), rs.getString("B_text"));
			sql = String.format("UPDATE %s SET B_hit = B_hit + 1 WHERE B_no = %s", DB_NAME, rs.getString("B_no"));
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("오류");
		}

	}

	public Dto getRead(String a) {
		post = null;
		dao("read", a);
		return post;
	}

	// 리스트
	private static void list(String a) {
		posts = new ArrayList<>();
		String sql;
			sql = String.format("SELECT * FROM %s where B_title like '%%%s%%' limit %s,%s ", DB_NAME, a,minpage, Board.PAGE);
		try {
			rs = st.executeQuery(sql);
			while (rs.next()) {
				posts.add(new Dto(rs.getString("B_no"),rs.getString("B_title"), rs.getString("B_time"),
						rs.getString("B_name"),rs.getString("B_name_num"),rs.getString("B_hit")));
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	// 페이징 작업

	private void count(String a) {
		String sql;
		sql = String.format("SELECT count(*) FROM %s where B_title like '%%%s%%' ", DB_NAME, a);
		try {
			rs = st.executeQuery(sql);
			rs.next();
				count = rs.getInt("count(*)");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int pageCount(String a) {
		dao("count", a);
		return count;
	}

	public int maxPage() {
		int max = 0;

		if (count % Board.PAGE > 0) {
			max = count / Board.PAGE + 1;
		} else {
			max = count / Board.PAGE;
		}
		return max;
	}

	public int pageLink() {
		return Board.PAGE_LINK;
	}

	public ArrayList<Dto> getList(String a, String b) {
		post = null;
		minpage = (Integer.parseInt(b) - 1) * Board.PAGE;
		dao("list", a);
		return posts;
	}

	// 수정
	private static void fix(String a) {
		String sql = String.format("UPDATE %s SET B_title = '%s' ,B_text = '%s' WHERE B_no = " + a, DB_NAME, post.title,
				post.text);
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
