package com.Jsp.Board.LoginDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Login extends LoginDb {
	private static Connection con = null;
	private static Statement st = null;
	private static ResultSet rs = null;
	private static LoginData login = null;
	private static LoginData my = null;
	private static LoginData join = null;
	private static String name = null;
	private static String no = null;
	private static String num = null;
	private static boolean ck = false;
	private static int namecount = 0;

	public static String name() {
		String name = null;
		if(my != null) {
			name = my.name;
		}
		return name;
	}
	public static String num() {
		String num = null;
		if(my != null) {
			num = my.num;
		}
		return num;
	}

	public static String no() {
	String nz = "0";
		try {
	nz = my.no;
	} catch (NullPointerException e) {
	}
		
		return nz;
	}

	public static void dao(String a) {
		try {
			Class.forName(DB_LINK);
			con = DriverManager.getConnection(DB_URL, DB_ID, DB_PW);
			st = con.createStatement();
			if (a.equals("join")) {
				join();
			} else if (a.equals("joinCount")) {
				joinCount();
			} else if (a.equals("nameMax")) {
				nameMax();
			} else if (a.equals("idCk")) {
				idCk();
			} else if (a.equals("myName")) {
				myName();
			}

			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean join(LoginData a) {
		ck = false;
		join = a;

		dao("joinCount");
		if (ck) {
			dao("nameMax");
			dao("join");
		}
		join = null;
		namecount = 0;
		return ck;
	}

	private static void joinCount() {
		String sql = String.format("SELECT count(*) FROM %s WHERE id = '%s'", DB_BOARD, join.id);
		try {
			rs = st.executeQuery(sql);
			while (rs.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				int idcount = rs.getInt("count(*)");
				if (idcount == 0) {
					ck = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private static void join() {
		String sql = String.format("INSERT INTO %s(id,pw,name,name_num) VALUES ('%s','%s','%s',%s)", DB_BOARD, join.id,
				join.pw, join.name, (namecount + 1));
		try {
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private static void nameMax() {
		String sql = String.format("SELECT max(name_num) FROM %s WHERE name = '" + join.name+ "'", DB_BOARD);
		try {
			rs = st.executeQuery(sql);
			while (rs.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				namecount = rs.getInt("max(name_num)");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static boolean login(LoginData a) {
		ck = false;
		login = a;
		dao("idCk");
		if (ck) {
			dao("myName");
			my = new LoginData(no,a.id,a.pw,name,num);
		}
		no = null;
		name = null;
		num = null;
		login = null;
		return ck;
	}	

	private static void myName() {
		String sql = "SELECT * FROM login WHERE id = '" + login.id + "' AND pw = '" + login.pw + "'";
		name = null;
		num = null;
		try {
			rs = st.executeQuery(sql);
			rs.next();
			name = rs.getString("name");
			num = rs.getString("name_num");
			no = rs.getString("name_num");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	

	private static void idCk() {
		String sql = "SELECT count(*) FROM login WHERE id = '" + login.id + "' AND pw = '" + login.pw + "'";
		try {
			rs = st.executeQuery(sql);
			rs.next();
			int inck = rs.getInt("count(*)");
			if (inck == 1) {
				ck = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void logout() {
		my = null;
	}

	// 회원가입

// 로그인

// 닉네임 변경

}
