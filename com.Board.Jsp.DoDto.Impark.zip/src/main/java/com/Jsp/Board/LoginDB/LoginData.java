package com.Jsp.Board.LoginDB;

public class LoginData {



	public String no;
	public String id;
	public String pw;
	public String name;
	public String num;
	
	
	public LoginData(String no,String id, String pw, String name,String num) {
		this.no = no;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.num = num;
	}
	
	public LoginData(String id, String pw, String name) {
		this.id = id;
		this.pw = pw;
		this.name = name;
	}
	public LoginData(String id, String pw) {
		this.id = id;
		this.pw = pw;
	}
	
	
}
